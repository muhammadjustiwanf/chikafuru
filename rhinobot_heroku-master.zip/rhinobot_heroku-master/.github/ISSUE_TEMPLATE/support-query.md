---
name: Support query
about: For help figuring out how to use the bot.
title: ''
labels: question
assignees: ''

---

**Your question** <!-- Please type your question below this line -->

**Bot version** <!-- Please include the release version of the bot you are using. -->
