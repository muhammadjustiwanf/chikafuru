---
name: Bot not working
about: Bot not working? Select this option.
title: ''
labels: issue
assignees: ''

---

**Describe the problem** <!-- Please describe your problem below this line -->

**Have you followed all the instructions?** <!-- Replace the [ ] below with [X] to indicate you followed the instructions. Otherwise, please go back and try to deploy the bot again following the instructions properly. -->
- [ ] Yes, I followed the instructions properly.

**Tried updating the dependencies?** <!-- Most of the time, updating them should make the bot work again. Follow the instructions in the readme to update them. -->
- [ ] Yes, they are up to date.
- [ ] Not applicable for this issue.

**Bot version** <!-- Please let us know the release version of the bot you are using. -->
